import type { MiddlewareHandler } from "hono";
import { randomBytes } from "node:crypto";

/**
 * Security response headers for the backend host (`mcp.<domain>`), which serves
 * HTML for the OAuth flow, QR login, and `/my/*` self-service — a clickjacking
 * + XSS surface that renders client-supplied values (client_name, redirect_uri,
 * state). Added after the 2026-06-11 security audit (finding H1).
 *
 * CSP is tuned to the actual page composition:
 *   - script-src 'self'         — islands are external ES modules under
 *                                 /app-assets/ (Layout.tsx `<script type=module src>`).
 *                                 NO inline scripts → no 'unsafe-inline', no nonce needed.
 *   - style-src 'self' 'unsafe-inline' — pages use an inline <style> block
 *                                 (hono/css → Layout) and React inline style={{}}.
 *                                 'unsafe-inline' for styles only is low-risk.
 *   - img-src 'self' data:      — the QR island injects <img src="data:image/png;...">.
 *   - connect-src 'self'        — QR login uses a same-origin SSE stream.
 *   - frame-ancestors 'none'    — defeats clickjacking of the OAuth approve flow
 *                                 (stronger than X-Frame-Options; both set for
 *                                 older-UA coverage).
 *   - base-uri 'none', object-src 'none', form-action 'self' — lock down the rest.
 *     Browsers apply form-action to the redirect that follows a form POST too,
 *     so the OAuth pages whose forms answer with a 302 to the client (review
 *     code, consent approve) add that client's validated redirect origin via
 *     contentSecurityPolicy(); with bare 'self' Chrome silently drops the
 *     redirect and the user is stuck on the page.
 *
 * HSTS is set unconditionally: the backend is HTTPS-only behind Traefik+LE, so
 * pinning a year of HTTPS closes the first-request downgrade window. No `preload`
 * yet (opt-in is hard to reverse); add once confident across all subdomains.
 */
export function contentSecurityPolicy(formActionSources: string[] = []): string {
  return [
    "default-src 'self'",
    "script-src 'self'",
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data:",
    "connect-src 'self'",
    "font-src 'self'",
    "frame-ancestors 'none'",
    "base-uri 'none'",
    "object-src 'none'",
    ["form-action 'self'", ...formActionSources].join(" "),
  ].join("; ");
}

const CSP = contentSecurityPolicy();

/**
 * CSP source matching an OAuth redirect URI: the origin for http(s), the bare
 * scheme for app callbacks (`cursor://…` → `cursor:`). Null for anything that
 * cannot be expressed safely as a single source token.
 */
export function formActionSource(redirectUri: string): string | null {
  let url: URL;
  try {
    url = new URL(redirectUri);
  } catch {
    return null;
  }
  if (url.protocol === "https:" || url.protocol === "http:") return url.origin;
  return /^[a-z][a-z0-9+.-]*:$/.test(url.protocol) ? url.protocol : null;
}

export const securityHeaders: MiddlewareHandler = async (c, next) => {
  await next();
  // The small self-hosted build uses Hono's fallback QR pages rather than the
  // optional React islands. Their inline scripts receive a fresh nonce for each
  // HTML response, while keeping the strict script policy for all other bodies.
  let csp = c.res.headers.get("Content-Security-Policy") ?? CSP;
  if (c.res.headers.get("Content-Type")?.includes("text/html") && c.res.body) {
    const html = await c.res.text();
    if (/<script\b/i.test(html)) {
      const nonce = randomBytes(18).toString("base64");
      const rewritten = html.replace(/<script\b(?![^>]*\bnonce\s*=)([^>]*)>/gi,
        (_tag, attrs: string) => `<script nonce="${nonce}"${attrs}>`);
      c.res = new Response(rewritten, { status: c.res.status, headers: c.res.headers });
      c.res.headers.delete("Content-Length");
      csp = csp.replace(/script-src\s+[^;]+/, `script-src 'self' 'nonce-${nonce}'`);
      c.header("Cache-Control", "private, no-store");
    } else {
      c.res = new Response(html, { status: c.res.status, headers: c.res.headers });
    }
  }
  c.header("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  // Download responses set a stricter sandbox CSP and no-referrer policy.
  // Do not overwrite those route-specific policies on the way back out.
  c.header("Content-Security-Policy", csp);
  c.header("X-Content-Type-Options", "nosniff");
  c.header("X-Frame-Options", "DENY");
  // same-origin, not no-referrer: under no-referrer browsers send `Origin: null`
  // on form POSTs, and every same-origin form here (settings, consent approve,
  // review code) checks Origin against the issuer, so they all returned 403
  // (issue #21). same-origin still sends nothing to other sites.
  c.header("Referrer-Policy", c.res.headers.get("Referrer-Policy") ?? "same-origin");
};
