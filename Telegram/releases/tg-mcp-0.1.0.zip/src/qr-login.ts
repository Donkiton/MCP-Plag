import type { TelegramService } from "@overpod/mcp-telegram/service";
import { config } from "./config.js";
import { withDeadline } from "./deadline.js";
import { logger, logUser } from "./logger.js";
import type { OAuthProvider } from "./oauth.js";
import { type QrLoginHooks, runQrLogin } from "./qr-login-core.js";
import { awaitPassword, newLoginId } from "./qr-password-channel.js";
import type { SessionManager } from "./session-manager.js";
import { TELEGRAM_SETUP_MESSAGE, telegramCredentialsConfigured } from "./tg-credentials.js";

// SSE comment-frame interval. Long enough to be cheap, short enough to stay under
// the ~15s HTTP/2 idle threshold we observed empirically against Traefik+Bun.serve.
const SSE_HEARTBEAT_INTERVAL_MS = 5000;

// How long the user has to type the 2FA cloud password after we prompt before
// the login attempt gives up. The SSE heartbeat keeps the stream warm meanwhile.
const PASSWORD_ENTRY_TIMEOUT_MS = 2 * 60 * 1000;

type Send = (event: string, data: unknown) => void;

/**
 * Wire the GramJS QR+2FA login to an SSE `send`. The cloud-password step is
 * bridged over a side channel: we emit `password_needed` with an unguessable
 * `loginId` and await the matching POST to `/qr/password` (see
 * qr-password-channel.ts). Status strings are English, surfaced verbatim like
 * the other SSE `status` events.
 */
function sseQrHooks(send: Send, loginId: string): QrLoginHooks {
  return {
    onQr: (dataUrl) => send("qr", { dataUrl }),
    onStatus: (message) => send("status", { message }),
    // `signal` is the attempt-scoped signal from runQrLogin — it already fires on
    // SSE abort AND on the 5-minute deadline, so the password wait unwinds with
    // the rest of the attempt instead of lingering until its own 2-min timeout.
    requestPassword: (hint, signal) => {
      send("password_needed", { loginId, hint: hint ?? "" });
      return awaitPassword(loginId, signal, PASSWORD_ENTRY_TIMEOUT_MS);
    },
    onPasswordRejected: () => send("status", { message: "Incorrect cloud password — please try again" }),
  };
}

/**
 * Materialize a freshly-obtained session string into a live `TelegramService`.
 * GramJS already destroyed its login client in `runQrLogin`, so reconnecting a
 * new client from the same StringSession is safe (no auth-key duplication).
 */
async function connectFromSession(sessions: SessionManager, sessionString: string) {
  const telegram = sessions.createTempTelegram();
  telegram.setSessionString(sessionString);
  try {
    const connected = await withDeadline("qr.verify.connect", config.telegramConnectTimeoutMs, () =>
      telegram.connect(),
    );
    if (!connected) throw new Error("Telegram could not verify the new session. Please retry the connection.");
    const me = await withDeadline("qr.verify.identity", config.telegramConnectTimeoutMs, () => telegram.getMe());
    return { telegram, me };
  } catch (error) {
    await telegram.disconnect().catch(() => {});
    throw error;
  }
}

type AccountLinkStore = Pick<
  SessionManager,
  "listAccounts" | "ensureAccountSession" | "renameAccount" | "replaceAccountSession" | "addAccount"
>;

/** Publish a QR result only after its temporary connection has closed. A
 * repeated scan is a sign-in, not a request to create another Telegram device. */
export async function retainOrAttachAccount(
  sessions: AccountLinkStore,
  ownerUserId: string,
  telegramUserId: string,
  fresh: TelegramService,
  sessionString: string,
  label: string | null,
): Promise<number> {
  const existing = sessions.listAccounts(ownerUserId).find((a) => a.telegramUserId === telegramUserId);
  let healthy = false;
  if (existing) {
    try {
      const stored = await sessions.ensureAccountSession(ownerUserId, existing.accountId);
      healthy = await withDeadline("qr.existing.ensureConnected", config.telegramConnectTimeoutMs, () =>
        stored.ensureConnected(),
      );
    } catch {
      /* Explicit QR reauthorization can repair this account only. */
    }
  }
  if (existing && healthy) {
    try {
      if (label?.trim()) sessions.renameAccount(ownerUserId, existing.accountId, label);
      return existing.accountId;
    } finally {
      try {
        await withDeadline("qr.signin.logOut", config.telegramConnectTimeoutMs, () => fresh.logOut());
      } catch {
        logger.warn("Could not revoke a sign-in-only Telegram device", {
          component: "qr-login",
          event: "qr.signin.logout_failed",
          userId: logUser(ownerUserId),
        });
      }
      await withDeadline("qr.signin.disconnect", config.telegramConnectTimeoutMs, () => fresh.disconnect()).catch(
        () => {},
      );
    }
  }
  try {
    // Await closure BEFORE making this new key visible to any MCP worker.
    await withDeadline("qr.accept.disconnect", config.telegramConnectTimeoutMs, () => fresh.disconnect());
    if (existing) {
      if (label?.trim()) sessions.renameAccount(ownerUserId, existing.accountId, label);
      await sessions.replaceAccountSession(ownerUserId, existing.accountId, sessionString);
      return existing.accountId;
    }
    return sessions.addAccount(ownerUserId, telegramUserId, sessionString, label);
  } catch (error) {
    // A failed validation/persistence must not leave an orphaned QR device.
    await withDeadline("qr.rejected.logOut", config.telegramConnectTimeoutMs, () => fresh.logOut()).catch(() => {});
    await withDeadline("qr.rejected.disconnect", config.telegramConnectTimeoutMs, () => fresh.disconnect()).catch(
      () => {},
    );
    throw error;
  }
}

/**
 * Storage key for a freshly authenticated Telegram account.
 *
 * Derived ONLY from the account that actually signed in. Exported so the rule
 * is unit-testable and so call sites cannot quietly reintroduce a
 * caller-supplied id: `/login/qr?userId=` is chosen by whoever opens the page,
 * and using it as the key let an attacker overwrite a victim's session row.
 */
export function sessionKeyForAccount(me: { username?: string | null; id: unknown }): string {
  return String(me.id);
}

function setupRequiredStream(): ReadableStream<Uint8Array> {
  return new ReadableStream({
    start(controller) {
      controller.enqueue(
        new TextEncoder().encode(`event: error_msg\ndata: ${JSON.stringify({ message: TELEGRAM_SETUP_MESSAGE })}\n\n`),
      );
      controller.close();
    },
  });
}

/**
 * Handle QR login via SSE stream.
 *
 * `requestedUserId` is a HINT ONLY (it comes from `?userId=` on /login/qr, i.e.
 * from whoever opened the page). It may be used to look up an existing session,
 * but it must never decide where a NEW session is stored: the storage key comes
 * from `getMe()` after the scan, so the row is owned by the account that
 * actually authenticated.
 *
 * Before this, `saveSessionString(requestedUserId, \u2026)` combined with
 * `ON CONFLICT(user_id) DO UPDATE` let anyone pass a victim's handle, scan with
 * their OWN phone and overwrite the victim's stored session \u2014 after which the
 * victim's still-valid OAuth tokens drove the attacker's Telegram account. The
 * OAuth variant of this flow (handleOAuthQrLogin below) always derived the id
 * from getMe(); this one did not, and that asymmetry was the whole bug.
 */
export async function handleQrLogin(
  sessions: SessionManager,
  requestedUserId: string,
  signal: AbortSignal,
  oauth: Pick<OAuthProvider, "createBrowserHandoff">,
): Promise<ReadableStream<Uint8Array>> {
  if (!telegramCredentialsConfigured()) return setupRequiredStream();
  const encoder = new TextEncoder();

  return new ReadableStream({
    async start(controller) {
      const send: Send = (event, data) => {
        if (signal.aborted) return;
        controller.enqueue(encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`));
      };

      // Keep the HTTP/2 stream warm so intermediaries (Traefik/Bun) don't close it during idle
      // gaps between qr.start and the eventual success/redirect. SSE comments (lines starting
      // with `:`) are ignored by EventSource but count as traffic on the underlying stream.
      const heartbeat = setInterval(() => {
        if (signal.aborted) {
          clearInterval(heartbeat);
          return;
        }
        try {
          controller.enqueue(encoder.encode(`: ping\n\n`));
        } catch {
          // Stream already closed/errored — nothing to do, finally will clear the interval.
        }
      }, SSE_HEARTBEAT_INTERVAL_MS);
      signal.addEventListener("abort", () => clearInterval(heartbeat), { once: true });

      try {
        // No "already connected" shortcut: this page also signs the browser in to
        // /my/*, and `requestedUserId` is whatever the visitor typed. Only a scan
        // proves who they are, so every visit scans.
        send("status", { message: "Starting QR login..." });

        const loginId = newLoginId();
        const outcome = await runQrLogin(sseQrHooks(send, loginId), signal);

        if (outcome.ok && outcome.sessionString) {
          // Reconnect a live client from the new session, confirm identity, then
          // persist + adopt — so a flaky reconnect never installs a broken pool
          // entry under this userId.
          const { telegram: fresh, me } = await connectFromSession(sessions, outcome.sessionString);
          // Identity comes from the scanned account, never from the query param.
          const userId = sessionKeyForAccount(me);
          if (userId !== requestedUserId) {
            logger.info("QR login stored under the scanned account, not the requested id", {
              component: "qr-login",
              event: "qr.identity.mismatch",
              userId: logUser(userId),
            });
          }
          await retainOrAttachAccount(sessions, userId, userId, fresh, outcome.sessionString, null);
          send("connected", {
            name: me.firstName,
            username: me.username,
            id: me.id,
            // Proof of identity for the browser: traded for the session cookie.
            handoff: oauth.createBrowserHandoff(userId),
          });
        } else {
          send("error_msg", { message: outcome.message ?? "QR login failed" });
        }
      } catch (err) {
        send("error_msg", { message: (err as Error).message });
      } finally {
        clearInterval(heartbeat);
      }

      controller.close();
    },
  });
}

/** Handle QR login as part of OAuth authorize flow */
export async function handleOAuthQrLogin(
  sessions: SessionManager,
  oauth: OAuthProvider,
  oauthParams: {
    clientId: string;
    redirectUri: string;
    state: string;
    codeChallenge: string;
    codeChallengeMethod: string;
  },
  userIdHint: string | undefined,
  signal: AbortSignal,
): Promise<ReadableStream<Uint8Array>> {
  if (!telegramCredentialsConfigured()) return setupRequiredStream();
  const encoder = new TextEncoder();

  return new ReadableStream({
    async start(controller) {
      const send: Send = (event, data) => {
        if (signal.aborted) return;
        controller.enqueue(encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`));
      };

      // Heartbeat is installed lazily — see `installHeartbeat` below. The fast `session.reuse`
      // path (a hinted user with a still-valid Telegram client) finishes in <200ms so the
      // heartbeat is unnecessary there; the slow QR-wait path installs it before blocking.
      let heartbeat: ReturnType<typeof setInterval> | null = null;
      const installHeartbeat = () => {
        if (heartbeat !== null || signal.aborted) return;
        heartbeat = setInterval(() => {
          if (signal.aborted) {
            if (heartbeat !== null) clearInterval(heartbeat);
            return;
          }
          try {
            controller.enqueue(encoder.encode(`: ping\n\n`));
          } catch {
            // Stream already closed/errored — finally will clear the interval.
          }
        }, SSE_HEARTBEAT_INTERVAL_MS);
        signal.addEventListener(
          "abort",
          () => {
            if (heartbeat !== null) clearInterval(heartbeat);
          },
          { once: true },
        );
      };

      try {
        // If we have a userId hint (from cookie), try to reconnect THAT specific user
        if (userIdHint) {
          logger.info(`Attempting session reuse for hinted user: ${logUser(userIdHint)}`, {
            component: "oauth-qr",
            event: "session.reuse.attempt",
            userId: logUser(userIdHint),
          });

          const telegram = await sessions.tryReconnectSession(userIdHint);

          if (telegram) {
            const me = await telegram.getMe();

            logger.info(`Reusing existing session (user reconnected)`, {
              component: "oauth-qr",
              userId: logUser(userIdHint),
              event: "user.reuse",
            });

            const code = oauth.createAuthCode({
              clientId: oauthParams.clientId,
              userId: userIdHint,
              redirectUri: oauthParams.redirectUri,
              codeChallenge: oauthParams.codeChallenge,
              codeChallengeMethod: oauthParams.codeChallengeMethod,
            });

            const url = new URL(oauthParams.redirectUri);
            url.searchParams.set("code", code);
            if (oauthParams.state) url.searchParams.set("state", oauthParams.state);

            send("redirect", {
              url: url.toString(),
              name: me.firstName ?? "",
              username: me.username ?? "unknown",
              id: me.id,
              // Page trades this for the session cookie (POST /oauth/authorize/qr/cookie).
              handoff: oauth.createBrowserHandoff(userIdHint),
            });
            controller.close();
            return;
          }

          logger.info(`Hinted session invalid, falling through to QR`, {
            component: "oauth-qr",
            event: "session.reuse.miss",
            userId: logUser(userIdHint),
          });
        }

        // No hint or hint failed — proceed with QR login (slow path: waits on user scan,
        // typically 5–30 seconds, longer if a 2FA password is required). Install the SSE
        // heartbeat now so the HTTP/2 stream stays warm through the confirmation round-trip.
        logger.info("Starting QR login (no valid session hint)", {
          component: "oauth-qr",
          event: "qr.start",
        });
        installHeartbeat();

        send("status", { message: "Scan the QR code with Telegram" });

        const loginId = newLoginId();
        const outcome = await runQrLogin(sseQrHooks(send, loginId), signal);

        if (outcome.ok && outcome.sessionString) {
          const { telegram, me } = await connectFromSession(sessions, outcome.sessionString);
          const userId = sessionKeyForAccount(me);

          await retainOrAttachAccount(sessions, userId, userId, telegram, outcome.sessionString, null);

          // Create OAuth auth code
          const code = oauth.createAuthCode({
            clientId: oauthParams.clientId,
            userId,
            redirectUri: oauthParams.redirectUri,
            codeChallenge: oauthParams.codeChallenge,
            codeChallengeMethod: oauthParams.codeChallengeMethod,
          });

          const url = new URL(oauthParams.redirectUri);
          url.searchParams.set("code", code);
          if (oauthParams.state) url.searchParams.set("state", oauthParams.state);

          const oauthClient = oauth.getClient(oauthParams.clientId);
          const clientName = oauthClient?.client_name ?? "";

          logger.info(`QR login success via ${clientName || "unknown"}`, {
            component: "oauth-qr",
            userId: logUser(userId),
            event: "user.login",
            client: clientName,
            clientId: oauthParams.clientId,
          });

          send("redirect", {
            url: url.toString(),
            name: me.firstName ?? "",
            username: me.username ?? "unknown",
            id: me.id,
            // The only way a browser session is born after QR: the server saw the
            // login finish, so it vouches for this user with a one-time ticket.
            handoff: oauth.createBrowserHandoff(userId),
          });
        } else {
          send("error_msg", { message: outcome.message ?? "QR login failed" });
        }
      } catch (err) {
        logger.error(`QR login error: ${(err as Error).message}`, { component: "oauth-qr", event: "user.login.error" });
        send("error_msg", { message: (err as Error).message });
      } finally {
        if (heartbeat !== null) clearInterval(heartbeat);
      }

      controller.close();
    },
  });
}

/**
 * v2.32.0 multi-account add-account QR flow.
 *
 * Wraps the standard QR-login UX (now including the 2FA cloud-password step),
 * then on success calls `sessions.addAccount(ownerUserId, …)` instead of saving
 * to `user_sessions`. Adding does not change any client's sender selection.
 * No OAuth token rotation and no impact on the primary account's session.
 *
 * Sends SSE events: `qr` (data URL), `status`, `password_needed` (2FA),
 * `added` (success with username), `error_msg`. Heartbeat lazily installed for
 * the slow QR-wait path.
 */
export async function handleAddAccountQr(
  sessions: SessionManager,
  ownerUserId: string,
  label: string | null,
  signal: AbortSignal,
): Promise<ReadableStream<Uint8Array>> {
  if (!telegramCredentialsConfigured()) return setupRequiredStream();
  const encoder = new TextEncoder();

  return new ReadableStream({
    async start(controller) {
      const send: Send = (event, data) => {
        if (signal.aborted) return;
        controller.enqueue(encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`));
      };

      let heartbeat: ReturnType<typeof setInterval> | null = null;
      const installHeartbeat = () => {
        if (heartbeat !== null || signal.aborted) return;
        heartbeat = setInterval(() => {
          if (signal.aborted) {
            if (heartbeat !== null) clearInterval(heartbeat);
            return;
          }
          try {
            controller.enqueue(encoder.encode(`: ping\n\n`));
          } catch {
            // Stream already closed/errored by the peer \u2014 the heartbeat has nothing
            // left to keep warm. `finally` clears the interval; logging here would
            // emit one line per disconnected client per tick for no diagnostic gain.
          }
        }, SSE_HEARTBEAT_INTERVAL_MS);
        signal.addEventListener(
          "abort",
          () => {
            if (heartbeat !== null) clearInterval(heartbeat);
          },
          { once: true },
        );
      };

      try {
        installHeartbeat();
        send("status", { message: "Scan the QR code with the Telegram account you want to add" });

        const loginId = newLoginId();
        const outcome = await runQrLogin(sseQrHooks(send, loginId), signal);

        if (!outcome.ok || !outcome.sessionString) {
          send("error_msg", { message: outcome.message ?? "QR login failed" });
          return;
        }

        const { telegram, me } = await connectFromSession(sessions, outcome.sessionString);
        const telegramUserId = sessionKeyForAccount(me);

        const accountId = await retainOrAttachAccount(
          sessions,
          ownerUserId,
          telegramUserId,
          telegram,
          outcome.sessionString,
          label,
        );

        logger.info(`Added secondary Telegram account #${accountId}`, {
          component: "accounts",
          event: "account.added",
          userId: logUser(ownerUserId),
          // `count` carries the new account_id — keeping log-fields strict
          // ALLOWED set free of one-off fields.
          count: accountId,
        });

        send("added", {
          accountId,
          username: me.username ?? "unknown",
          name: me.firstName ?? "",
          label: label ?? "",
        });
      } catch (err) {
        logger.error(`Add-account QR error: ${(err as Error).message}`, {
          component: "accounts",
          event: "account.add_error",
        });
        send("error_msg", { message: (err as Error).message });
      } finally {
        if (heartbeat !== null) clearInterval(heartbeat);
      }

      controller.close();
    },
  });
}
